import React, { Component } from 'react';
import Login from './components/login/Login';

class App extends Component {
	render() {
		return (
			<div className="App">
				<Login />
			</div>
		);
	}
}

export default App;
